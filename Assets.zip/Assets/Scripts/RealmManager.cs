using UnityEngine;
using TMPro;
public class RealmManager : MonoBehaviour
{
    public Camera cam;
    public Color natureColor = new Color(0.6f, 0.85f, 0.6f);
    public Color techColor = new Color(0.2f, 0.2f, 0.4f);

    [Header("Realm Roots")]
    public GameObject natureRealm;
    public GameObject techRealm;

    public TextMeshProUGUI realmText;

    private bool inNatureRealm = true;

    void Start()
    {
        SetRealm(true);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.LeftShift))
        {
            inNatureRealm = !inNatureRealm;
            SetRealm(inNatureRealm);
        }
    }

    void SetRealm(bool useNature)
    {
        natureRealm.SetActive(useNature);
        techRealm.SetActive(!useNature);

        cam.backgroundColor = useNature ? natureColor : techColor;

        realmText.text = useNature ? "Nature Realm" : "Tech Realm";
    }
}
